package com.abhishekkange.readerspoint.models;

public class bookInfoModel {

    //Creating the required
    public int bookImage;
    public String bookText;

    public bookInfoModel(int bookImage, String bookText) {
        this.bookImage = bookImage;
        this.bookText = bookText;
    }

    public int getBookImage() {
        return bookImage;
    }

    public void setBookImage(int bookImage) {
        this.bookImage = bookImage;
    }

    public String getBookText() {
        return bookText;
    }

    public void setBookText(String bookText) {
        this.bookText = bookText;
    }
}
