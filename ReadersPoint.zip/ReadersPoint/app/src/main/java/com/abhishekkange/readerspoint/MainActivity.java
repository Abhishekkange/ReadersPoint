package com.abhishekkange.readerspoint;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.abhishekkange.readerspoint.fragments.novelFragment;

public class MainActivity extends AppCompatActivity {

    //creating object of category textviews
    TextView novel,selfhelp,finnance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Using findViewById function to link it with XML

        novel = findViewById(R.id.novelBtn);
        selfhelp = findViewById(R.id.selfhelpBtn);
        finnance = findViewById(R.id.financeBtn);

        //Adding Onclick Listenrs on the above objects

        novel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Fragment Transaction code
                novelFragment novelFrag = new novelFragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame1,novelFrag);
                transaction.commit();

            }
        });
        selfhelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



            }
        });

        finnance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {





            }
        });


    }
}