package com.abhishekkange.readerspoint.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.abhishekkange.readerspoint.R;
import com.abhishekkange.readerspoint.models.bookInfoModel;

import java.util.ArrayList;

public class bookAdapter extends RecyclerView.Adapter<bookAdapter.viewHolder> {

    ArrayList<bookInfoModel> list;
    Context context;

    public bookAdapter(ArrayList<bookInfoModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.layout,parent,false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {


        bookInfoModel model = list.get(position);
        holder.bookImage.setImageResource(model.getBookImage());
        holder.bookName.setText(model.bookText);




    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class viewHolder extends RecyclerView.ViewHolder{

        ImageView bookImage;
        TextView bookName;


        public viewHolder(@NonNull View itemView) {
            super(itemView);


            bookName = itemView.findViewById(R.id.layoutBookName);
            bookImage = itemView.findViewById(R.id.layoutBookImage);


        }
    }



    
}
